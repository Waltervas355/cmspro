<?php 


require_once "controlador/ctrPlantilla.php";
require_once "controlador/ctrRutas.php";
require_once "controlador/ctrGrupos.php";
require_once "controlador/ctrCategorias.php";
require_once "controlador/ctrPerfiles.php";
require_once "controlador/ctrAnuncios.php";

require_once "modelo/modelo.grupos.php";
require_once "modelo/modelo.categorias.php";
require_once "modelo/modelo.perfiles.php";
require_once "modelo/modelo.anuncios.php";


$plantilla = plantilla::ctrPlantilla();


?>