<?php 

class plantilla{


    static public function ctrPlantilla(){


        include "vistas/plantilla.php";




    }




}


?>