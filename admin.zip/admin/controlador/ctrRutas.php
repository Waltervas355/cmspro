<?php 



class Rutas{


    static public function ctrRecursos(){


        return "http://localhost/PROYECTOSWEB/directorioCMS/admin/vistas/recursos/";




    }

      static public function ctrRutaFoto(){


        return "http://localhost/PROYECTOSWEB/directorioCMS/admin/";




    }





}




?>